class Date{
    public static String today(){
        return "2020/01/20";
    }
}