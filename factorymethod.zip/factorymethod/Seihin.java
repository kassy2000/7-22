abstract class Seihin{
    public abstract void print();
}